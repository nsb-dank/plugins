<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ja_JP">
<context>
    <name>CreateLayerGroupDialog</name>
    <message>
        <location filename="../create_layer_group_dialog.py" line="91"/>
        <source>Please enter the layer type.</source>
        <translation>レイヤの種類を選択してください。</translation>
    </message>
    <message>
        <location filename="../ui_create_layer_group_dialog.py" line="69"/>
        <source>Create Layer Group</source>
        <translation>レイヤーグループを作成</translation>
    </message>
    <message>
        <location filename="../ui_create_layer_group_dialog.py" line="70"/>
        <source>GeoPackage Name</source>
        <translation>GeoPackage名</translation>
    </message>
    <message>
        <location filename="../ui_create_layer_group_dialog.py" line="72"/>
        <source>Create</source>
        <translation>作成</translation>
    </message>
    <message>
        <location filename="../ui_create_layer_group_dialog.py" line="73"/>
        <source>Cancel</source>
        <translation>キャンセル</translation>
    </message>
    <message>
        <location filename="../ui_create_layer_group_dialog.py" line="75"/>
        <source>Group Name</source>
        <translation>グループ名</translation>
    </message>
    <message>
        <location filename="../ui_create_layer_group_dialog.py" line="76"/>
        <source>Layer Type</source>
        <translation>レイヤー種類</translation>
    </message>
    <message>
        <location filename="../ui_create_layer_group_dialog.py" line="77"/>
        <source>Scenario Map</source>
        <translation>Scenario Map</translation>
    </message>
    <message>
        <location filename="../ui_create_layer_group_dialog.py" line="70"/>
        <source>Geological Map</source>
        <translation type="obsolete">Geological Map</translation>
    </message>
    <message>
        <location filename="../ui_create_layer_group_dialog.py" line="79"/>
        <source> (single-byte character only)</source>
        <translation> （半角英数のみで指定してください）</translation>
    </message>
    <message>
        <location filename="../ui_create_layer_group_dialog.py" line="71"/>
        <source>e.g. scenario01</source>
        <translation>例） scenario01</translation>
    </message>
    <message>
        <location filename="../ui_create_layer_group_dialog.py" line="74"/>
        <source>e.g. 1. Major geosites</source>
        <translation>例） 1.主なジオサイト</translation>
    </message>
    <message>
        <location filename="../ui_create_layer_group_dialog.py" line="78"/>
        <source>Subject Map</source>
        <translation>Subject Map</translation>
    </message>
    <message>
        <location filename="../ui_create_layer_group_dialog.py" line="80"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;- Scenario Map =&amp;gt; Create a layer group under the [Scenario] Gourp.&lt;/p&gt;&lt;p&gt;- Subject Map  =&amp;gt; Create a layer group under the [Subject] Gourp.&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>・Scenario Map：「Scenario」グループ配下にレイヤーグループを追加します。
・Subject Map　：「Subject」グループ配下にレイヤーグループを追加します。</translation>
    </message>
    <message>
        <location filename="../create_layer_group_dialog.py" line="54"/>
        <source>The group name not been entered. Please enter.</source>
        <translation>グループ名を入力してください。</translation>
    </message>
    <message>
        <location filename="../create_layer_group_dialog.py" line="56"/>
        <source>The geopackage name has not been entered. Please enter.</source>
        <translation>GeoPackage名を入力してください。</translation>
    </message>
</context>
<context>
    <name>CreateProjectDialog</name>
    <message>
        <location filename="../ui_create_project_dialog.py" line="86"/>
        <source>Create Project</source>
        <translation>プロジェクト新規作成</translation>
    </message>
    <message>
        <location filename="../ui_create_project_dialog.py" line="87"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../ui_create_project_dialog.py" line="88"/>
        <source>Project Folder</source>
        <translation>プロジェクトフォルダ</translation>
    </message>
    <message>
        <location filename="../ui_create_project_dialog.py" line="89"/>
        <source>Base Map (Tile)</source>
        <translation>背景地図（タイル）</translation>
    </message>
    <message>
        <location filename="../ui_create_project_dialog.py" line="90"/>
        <source>Create</source>
        <translation>作成</translation>
    </message>
    <message>
        <location filename="../ui_create_project_dialog.py" line="91"/>
        <source>Cancel</source>
        <translation>キャンセル</translation>
    </message>
    <message>
        <location filename="../ui_create_project_dialog.py" line="92"/>
        <source>Project Title</source>
        <translation>タイトル</translation>
    </message>
    <message>
        <location filename="../create_project_dialog.py" line="78"/>
        <source>Confirmation</source>
        <translation>確認</translation>
    </message>
    <message>
        <location filename="../create_project_dialog.py" line="78"/>
        <source>When I create a new project, the map canvas data will be discarded.
 Are you sure?</source>
        <translation>現在のキャンバスは破棄されます。よろしいですか？</translation>
    </message>
    <message>
        <location filename="../ui_create_project_dialog.py" line="93"/>
        <source>Project File Name</source>
        <translation>プロジェクトファイル名</translation>
    </message>
    <message>
        <location filename="../ui_create_project_dialog.py" line="94"/>
        <source>GSI Map(Standard)</source>
        <translation>GSI Map(Standard)</translation>
    </message>
    <message>
        <location filename="../ui_create_project_dialog.py" line="95"/>
        <source>GIS Map(Pale)</source>
        <translation>GSI Map(Pale)</translation>
    </message>
    <message>
        <location filename="../ui_create_project_dialog.py" line="96"/>
        <source>GSI Map(Rerief)</source>
        <translation>GSI Map(Rerief)</translation>
    </message>
    <message>
        <location filename="../ui_create_project_dialog.py" line="97"/>
        <source>GIS Map(Photo)</source>
        <translation>GSI Map(Photo)</translation>
    </message>
    <message>
        <location filename="../ui_create_project_dialog.py" line="98"/>
        <source>Open Street Map</source>
        <translation>Open Street Map</translation>
    </message>
    <message>
        <location filename="../ui_create_project_dialog.py" line="99"/>
        <source>.qgs  (single-byte character only)</source>
        <translation>.qgs（半角英数のみで指定してください）</translation>
    </message>
    <message>
        <location filename="../ui_create_project_dialog.py" line="101"/>
        <source>EPSG:4612 (JGD2000)</source>
        <translation>EPSG:4612 (JGD2000)</translation>
    </message>
    <message>
        <location filename="../ui_create_project_dialog.py" line="100"/>
        <source>EPSG:4326 (WGS 84)</source>
        <translation>EPSG4326 (WGS 84)</translation>
    </message>
    <message>
        <location filename="../ui_create_project_dialog.py" line="102"/>
        <source>Project CRS</source>
        <translation>プロジェクトCRS</translation>
    </message>
    <message>
        <location filename="../create_project_dialog.py" line="69"/>
        <source>The project folder not been entered. Please enter.</source>
        <translation>プロジェクトフォルダを指定してください。</translation>
    </message>
    <message>
        <location filename="../create_project_dialog.py" line="71"/>
        <source>The project file name has not been entered. Please enter.</source>
        <translation>プロジェクトファイル名を入力してください。</translation>
    </message>
    <message>
        <location filename="../create_project_dialog.py" line="73"/>
        <source>The project title has not been entered. Please enter.</source>
        <translation>プロジェクトの表題を入力してください。</translation>
    </message>
</context>
<context>
    <name>EditAttributeDialog</name>
    <message>
        <location filename="../ui_edit_attribute_dialog.py" line="193"/>
        <source>Edit Attribute Dialog</source>
        <translation>属性編集ダイアログ</translation>
    </message>
    <message>
        <location filename="../ui_edit_attribute_dialog.py" line="194"/>
        <source>Description</source>
        <translation>コメント</translation>
    </message>
    <message>
        <location filename="../ui_edit_attribute_dialog.py" line="195"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../ui_edit_attribute_dialog.py" line="196"/>
        <source>Cancel</source>
        <translation>キャンセル</translation>
    </message>
    <message>
        <location filename="../ui_edit_attribute_dialog.py" line="197"/>
        <source>Style</source>
        <translation>スタイル</translation>
    </message>
    <message>
        <location filename="../ui_edit_attribute_dialog.py" line="198"/>
        <source>Symbol</source>
        <translation>シンボル</translation>
    </message>
    <message>
        <location filename="../ui_edit_attribute_dialog.py" line="199"/>
        <source>Legend01</source>
        <translation>凡例1</translation>
    </message>
    <message>
        <location filename="../ui_edit_attribute_dialog.py" line="200"/>
        <source>Legend07</source>
        <translation>地層形状詳細</translation>
    </message>
    <message>
        <location filename="../ui_edit_attribute_dialog.py" line="201"/>
        <source>Legend06</source>
        <translation>岩相</translation>
    </message>
    <message>
        <location filename="../ui_edit_attribute_dialog.py" line="202"/>
        <source>Legend03</source>
        <translation>層群(Group)名</translation>
    </message>
    <message>
        <location filename="../ui_edit_attribute_dialog.py" line="203"/>
        <source>Legend02</source>
        <translation>地質年代</translation>
    </message>
    <message>
        <location filename="../ui_edit_attribute_dialog.py" line="204"/>
        <source>Legend04</source>
        <translation>地層(Formation)名</translation>
    </message>
    <message>
        <location filename="../ui_edit_attribute_dialog.py" line="205"/>
        <source>Legend05</source>
        <translation>部層(Member)名</translation>
    </message>
    <message>
        <location filename="../ui_edit_attribute_dialog.py" line="212"/>
        <source>E</source>
        <translation>E</translation>
    </message>
    <message>
        <location filename="../ui_edit_attribute_dialog.py" line="213"/>
        <source>W</source>
        <translation>W</translation>
    </message>
    <message>
        <location filename="../ui_edit_attribute_dialog.py" line="215"/>
        <source>S</source>
        <translation>S</translation>
    </message>
    <message>
        <location filename="../ui_edit_attribute_dialog.py" line="209"/>
        <source>Strike</source>
        <translation>走向</translation>
    </message>
    <message>
        <location filename="../ui_edit_attribute_dialog.py" line="210"/>
        <source>Dip</source>
        <translation>傾斜</translation>
    </message>
    <message>
        <location filename="../ui_edit_attribute_dialog.py" line="214"/>
        <source>N</source>
        <translation>N</translation>
    </message>
    <message>
        <location filename="../ui_edit_attribute_dialog.py" line="216"/>
        <source>Select</source>
        <translation>選択</translation>
    </message>
    <message>
        <location filename="../ui_edit_attribute_dialog.py" line="217"/>
        <source>Filename</source>
        <translation>ファイル名</translation>
    </message>
    <message>
        <location filename="../ui_edit_attribute_dialog.py" line="218"/>
        <source>Preview</source>
        <translation>プレビュー</translation>
    </message>
</context>
<context>
    <name>ExportToGeolibDialog</name>
    <message>
        <location filename="../ui_export_to_geolib_dialog.py" line="341"/>
        <source>Export Layer Data to Geolib</source>
        <translation>Webライブラリにエクスポート</translation>
    </message>
    <message>
        <location filename="../ui_export_to_geolib_dialog.py" line="384"/>
        <source>Cancel</source>
        <translation>キャンセル</translation>
    </message>
    <message>
        <location filename="../ui_export_to_geolib_dialog.py" line="345"/>
        <source>Connect</source>
        <translation>接続</translation>
    </message>
    <message>
        <location filename="../ui_export_to_geolib_dialog.py" line="346"/>
        <source>New Article</source>
        <translation>新規ライブラリ</translation>
    </message>
    <message>
        <location filename="../ui_export_to_geolib_dialog.py" line="347"/>
        <source>Edit Article</source>
        <translation>ライブラリを編集</translation>
    </message>
    <message>
        <location filename="../ui_export_to_geolib_dialog.py" line="348"/>
        <source>Article</source>
        <translation>ライブラリ</translation>
    </message>
    <message>
        <location filename="../ui_export_to_geolib_dialog.py" line="349"/>
        <source>Update Date</source>
        <translation>更新日</translation>
    </message>
    <message>
        <location filename="../ui_export_to_geolib_dialog.py" line="352"/>
        <source>1999/01/01</source>
        <translation>1999/01/01</translation>
    </message>
    <message>
        <location filename="../ui_export_to_geolib_dialog.py" line="351"/>
        <source>Create Date</source>
        <translation>作成日</translation>
    </message>
    <message>
        <location filename="../ui_export_to_geolib_dialog.py" line="353"/>
        <source>Published</source>
        <translation>公開</translation>
    </message>
    <message>
        <location filename="../ui_export_to_geolib_dialog.py" line="354"/>
        <source>Abstract</source>
        <translation>概要</translation>
    </message>
    <message>
        <location filename="../ui_export_to_geolib_dialog.py" line="355"/>
        <source>Level</source>
        <translation>レベル</translation>
    </message>
    <message>
        <location filename="../ui_export_to_geolib_dialog.py" line="356"/>
        <source>Area</source>
        <translation>地域</translation>
    </message>
    <message>
        <location filename="../ui_export_to_geolib_dialog.py" line="383"/>
        <source>Save</source>
        <translation>保存</translation>
    </message>
    <message>
        <location filename="../ui_export_to_geolib_dialog.py" line="359"/>
        <source>Name</source>
        <translation>ライブラリ名</translation>
    </message>
    <message>
        <location filename="../ui_export_to_geolib_dialog.py" line="380"/>
        <source>Title</source>
        <translation>表題</translation>
    </message>
    <message>
        <location filename="../export_to_geolib_dialog.py" line="244"/>
        <source> files are registed.</source>
        <translation> 個のファイルが登録されています。</translation>
    </message>
    <message>
        <location filename="../export_to_geolib_dialog.py" line="650"/>
        <source>Do not export</source>
        <translation>アップロードしません</translation>
    </message>
    <message>
        <location filename="../ui_export_to_geolib_dialog.py" line="342"/>
        <source>Close</source>
        <translation>閉じる</translation>
    </message>
    <message>
        <location filename="../ui_export_to_geolib_dialog.py" line="343"/>
        <source>Please click the [Connect] button to connect to the server.</source>
        <translation>[接続]ボタンをクリックしてサーバーに接続してください。</translation>
    </message>
    <message>
        <location filename="../ui_export_to_geolib_dialog.py" line="344"/>
        <source>List of already registered libraries is displayed.</source>
        <translation>既に登録済のライブラリをリスト表示します。</translation>
    </message>
    <message>
        <location filename="../ui_export_to_geolib_dialog.py" line="363"/>
        <source>Map Data</source>
        <translation>マップデータ</translation>
    </message>
    <message>
        <location filename="../ui_export_to_geolib_dialog.py" line="368"/>
        <source>Export and Replace</source>
        <translation>アップロードする</translation>
    </message>
    <message>
        <location filename="../ui_export_to_geolib_dialog.py" line="347"/>
        <source>Symbol Icons;</source>
        <translation type="obsolete">シンボルアイコン：</translation>
    </message>
    <message>
        <location filename="../ui_export_to_geolib_dialog.py" line="366"/>
        <source>Scenario Map</source>
        <translation>シナリオマップ</translation>
    </message>
    <message>
        <location filename="../ui_export_to_geolib_dialog.py" line="367"/>
        <source>Scenario Files:</source>
        <translation>シナリオファイル：</translation>
    </message>
    <message>
        <location filename="../ui_export_to_geolib_dialog.py" line="369"/>
        <source>Subject Map</source>
        <translation>主題図</translation>
    </message>
    <message>
        <location filename="../ui_export_to_geolib_dialog.py" line="372"/>
        <source>There is no file.</source>
        <translation>ファイルは登録されていません。</translation>
    </message>
    <message>
        <location filename="../ui_export_to_geolib_dialog.py" line="373"/>
        <source>Associated Map</source>
        <translation>関連図</translation>
    </message>
    <message>
        <location filename="../ui_export_to_geolib_dialog.py" line="374"/>
        <source>New Map Regist</source>
        <translation>新規マップ登録</translation>
    </message>
    <message>
        <location filename="../ui_export_to_geolib_dialog.py" line="375"/>
        <source>Double-click a line to edit it</source>
        <translation>ダブルクリックして編集</translation>
    </message>
    <message>
        <location filename="../ui_export_to_geolib_dialog.py" line="376"/>
        <source>Export Map</source>
        <translation>マップをエクスポート</translation>
    </message>
    <message>
        <location filename="../ui_export_to_geolib_dialog.py" line="377"/>
        <source>Scenario</source>
        <translation>Scenario</translation>
    </message>
    <message>
        <location filename="../ui_export_to_geolib_dialog.py" line="378"/>
        <source>Subject</source>
        <translation>Subject</translation>
    </message>
    <message>
        <location filename="../ui_export_to_geolib_dialog.py" line="379"/>
        <source>Associated</source>
        <translation>Associated</translation>
    </message>
    <message>
        <location filename="../ui_export_to_geolib_dialog.py" line="382"/>
        <source>Map Type</source>
        <translation>マップの種類</translation>
    </message>
    <message>
        <location filename="../ui_export_to_geolib_dialog.py" line="385"/>
        <source>Attribution</source>
        <translation>著作表示</translation>
    </message>
    <message>
        <location filename="../ui_export_to_geolib_dialog.py" line="386"/>
        <source>Script</source>
        <translation>スクリプト</translation>
    </message>
    <message>
        <location filename="../ui_export_to_geolib_dialog.py" line="387"/>
        <source>GeoJSON</source>
        <translation>GeoJSON</translation>
    </message>
    <message>
        <location filename="../ui_export_to_geolib_dialog.py" line="388"/>
        <source>geoTIFF</source>
        <translation>geoTIFF</translation>
    </message>
    <message>
        <location filename="../ui_export_to_geolib_dialog.py" line="389"/>
        <source>Source Type</source>
        <translation>ソースのタイプ</translation>
    </message>
    <message>
        <location filename="../ui_export_to_geolib_dialog.py" line="390"/>
        <source>Layer Data</source>
        <translation>保存先フォルダ</translation>
    </message>
    <message>
        <location filename="../ui_export_to_geolib_dialog.py" line="365"/>
        <source>Symbol Icons:</source>
        <translation>シンボルアイコン：</translation>
    </message>
    <message>
        <location filename="../ui_export_to_geolib_dialog.py" line="370"/>
        <source>Upload checked files</source>
        <translation>チェックしたファイルをアップロード</translation>
    </message>
    <message>
        <location filename="../export_to_geolib_dialog.py" line="112"/>
        <source>Your email address or password is incorrect. Please review the settings.</source>
        <translation type="obsolete">メールアドレスまたはパスワードが間違っています。設定を確認してください。</translation>
    </message>
    <message>
        <location filename="../export_to_geolib_dialog.py" line="533"/>
        <source>Database connect error!</source>
        <translation>データベース接続エラー！</translation>
    </message>
    <message>
        <location filename="../ui_export_to_geolib_dialog.py" line="392"/>
        <source>Delete</source>
        <translation>削除</translation>
    </message>
    <message>
        <location filename="../export_to_geolib_dialog.py" line="99"/>
        <source>[ %s ] Article list:</source>
        <translation>[ %s ]の登録ライブラリ一覧</translation>
    </message>
    <message>
        <location filename="../export_to_geolib_dialog.py" line="176"/>
        <source>No Data</source>
        <translation>データがありません</translation>
    </message>
    <message>
        <location filename="../ui_export_to_geolib_dialog.py" line="357"/>
        <source>e.g. Geological Map for  my town</source>
        <translation>例） 私の町の地質図</translation>
    </message>
    <message>
        <location filename="../ui_export_to_geolib_dialog.py" line="358"/>
        <source>e.g. My town map</source>
        <translation>例） 私の町の地図</translation>
    </message>
    <message>
        <location filename="../ui_export_to_geolib_dialog.py" line="381"/>
        <source>e.g. Observation point</source>
        <translation>例）　観測地点</translation>
    </message>
    <message>
        <location filename="../ui_export_to_geolib_dialog.py" line="391"/>
        <source>e.g. Folder_A</source>
        <translation>例） folder_A</translation>
    </message>
    <message>
        <location filename="../export_to_geolib_dialog.py" line="278"/>
        <source>The library name has not been entered. Please enter.</source>
        <translation>ライブラリ名を入力してください。</translation>
    </message>
    <message>
        <location filename="../export_to_geolib_dialog.py" line="280"/>
        <source>The library title has not been entered. Please enter.</source>
        <translation>ライブラリの表題を入力してください。</translation>
    </message>
    <message>
        <location filename="../export_to_geolib_dialog.py" line="340"/>
        <source>Completed to save the library data.</source>
        <translation>サーバーへのライブラリデータの保存が完了しました。</translation>
    </message>
    <message>
        <location filename="../export_to_geolib_dialog.py" line="417"/>
        <source>Completed to upload the library files.</source>
        <translation>ライブラリファイルのアップロードが完了しました。</translation>
    </message>
    <message>
        <location filename="../export_to_geolib_dialog.py" line="487"/>
        <source>The map title has not been entered. Please enter.</source>
        <translation>表題を入力してください。</translation>
    </message>
    <message>
        <location filename="../export_to_geolib_dialog.py" line="489"/>
        <source>The folder name has not been entered. Please enter.</source>
        <translation>保存先フォルダ名を入力してください。</translation>
    </message>
    <message>
        <location filename="../export_to_geolib_dialog.py" line="570"/>
        <source>Completed to save the map data and upload the map files.</source>
        <translation>マップデータの保存とファイルのアップロードが完了しました。</translation>
    </message>
    <message>
        <location filename="../export_to_geolib_dialog.py" line="574"/>
        <source>Confirmation</source>
        <translation>確認</translation>
    </message>
    <message>
        <location filename="../export_to_geolib_dialog.py" line="347"/>
        <source>All data and files in the library will be deleted.
 Are you sure?</source>
        <translation>サーバー内のライブラリデータおよびファイルを削除します。よろしいですか？</translation>
    </message>
    <message>
        <location filename="../export_to_geolib_dialog.py" line="574"/>
        <source>All data and files in the map will be deleted.
 Are you sure?</source>
        <translation>サーバー内のマップデータおよびファイルを削除します。よろしいですか？</translation>
    </message>
    <message>
        <location filename="../export_to_geolib_dialog.py" line="375"/>
        <source>If uploaded files contain images, uploading may take some time..
 Are you sure?</source>
        <translation>アップロードファイルに画像が含まれている場合、時間がかかることがあります。
よろしいですか？</translation>
    </message>
    <message>
        <location filename="../export_to_geolib_dialog.py" line="606"/>
        <source>Completed to delete the map data and files.</source>
        <translation>マップデータとファイルを削除しました。</translation>
    </message>
</context>
<context>
    <name>Geolib</name>
    <message>
        <location filename="../geolib.py" line="344"/>
        <source>&amp;Geoscience Library Tool</source>
        <translation type="obsolete">&amp;地学ライブラリツール</translation>
    </message>
    <message>
        <location filename="../geolib.py" line="71"/>
        <source>Geoscience Library Tool</source>
        <translation type="obsolete">地学ライブラリツール</translation>
    </message>
    <message>
        <location filename="../geolib.py" line="113"/>
        <source>Project Tool</source>
        <translation type="obsolete">プロジェクトツール</translation>
    </message>
    <message>
        <location filename="../geolib.py" line="121"/>
        <source>Create New Project</source>
        <translation type="obsolete">プロジェクトの新規作成</translation>
    </message>
    <message>
        <location filename="../geolib.py" line="121"/>
        <source>Create new project</source>
        <translation type="obsolete">プロジェクトの新規作成</translation>
    </message>
    <message>
        <location filename="../geolib.py" line="132"/>
        <source>Open Geolib project</source>
        <translation type="obsolete">プロジェクトを開く</translation>
    </message>
    <message>
        <location filename="../geolib.py" line="132"/>
        <source>Select QGIS project file</source>
        <translation type="obsolete">QGISプロジェクトファイルを選択</translation>
    </message>
    <message>
        <location filename="../geolib.py" line="145"/>
        <source>Layer Tool</source>
        <translation type="obsolete">レイヤーツール</translation>
    </message>
    <message>
        <location filename="../geolib.py" line="153"/>
        <source>Create Layer Group</source>
        <translation type="obsolete">レイヤーグループを作成</translation>
    </message>
    <message>
        <location filename="../geolib.py" line="153"/>
        <source>Create new layer group</source>
        <translation type="obsolete">レイヤーグループを作成</translation>
    </message>
    <message>
        <location filename="../geolib.py" line="162"/>
        <source>Edit Scenario Contents</source>
        <translation type="obsolete">シナリオコンテンツを編集</translation>
    </message>
    <message>
        <location filename="../geolib.py" line="162"/>
        <source>Edit scenario contents</source>
        <translation type="obsolete">シナリオコンテンツを編集</translation>
    </message>
    <message>
        <location filename="../geolib.py" line="171"/>
        <source>Import Geoclino Data</source>
        <translation type="obsolete">Geoclinoデータをインポート</translation>
    </message>
    <message>
        <location filename="../geolib.py" line="171"/>
        <source>Import Geoclino xml data</source>
        <translation type="obsolete">Geoclino XMLデータをインポート</translation>
    </message>
    <message>
        <location filename="../geolib.py" line="183"/>
        <source>Save Active Layer Data</source>
        <translation type="obsolete">現在のレイヤーを保存</translation>
    </message>
    <message>
        <location filename="../geolib.py" line="183"/>
        <source>Save active layer data</source>
        <translation type="obsolete">現在のレイヤーを保存</translation>
    </message>
    <message>
        <location filename="../geolib.py" line="203"/>
        <source>Add Feature</source>
        <translation type="obsolete">地物を追加</translation>
    </message>
    <message>
        <location filename="../geolib.py" line="203"/>
        <source>Add new feature in active layer</source>
        <translation type="obsolete">現在のレイヤに新規地物を追加</translation>
    </message>
    <message>
        <location filename="../geolib.py" line="193"/>
        <source>Edit  Attribute</source>
        <translation type="obsolete">属性を編集</translation>
    </message>
    <message>
        <location filename="../geolib.py" line="193"/>
        <source>Edit selected featues attribute</source>
        <translation type="obsolete">選択した地物の属性を編集</translation>
    </message>
    <message>
        <location filename="../geolib.py" line="213"/>
        <source>Move Feature</source>
        <translation type="obsolete">地物を移動</translation>
    </message>
    <message>
        <location filename="../geolib.py" line="213"/>
        <source>Move selected features</source>
        <translation type="obsolete">選択した地物を移動</translation>
    </message>
    <message>
        <location filename="../geolib.py" line="223"/>
        <source>Edit Node</source>
        <translation type="obsolete">ノードを編集</translation>
    </message>
    <message>
        <location filename="../geolib.py" line="223"/>
        <source>Edit node</source>
        <translation type="obsolete">ノードを編集</translation>
    </message>
    <message>
        <location filename="../geolib.py" line="233"/>
        <source>Split Feature</source>
        <translation type="obsolete">地物を分割</translation>
    </message>
    <message>
        <location filename="../geolib.py" line="243"/>
        <source>Merge Features</source>
        <translation type="obsolete">地物を結合</translation>
    </message>
    <message>
        <location filename="../geolib.py" line="243"/>
        <source>Merge features</source>
        <translation type="obsolete">地物を結合</translation>
    </message>
    <message>
        <location filename="../geolib.py" line="253"/>
        <source>Delete Feature</source>
        <translation type="obsolete">地物を削除</translation>
    </message>
    <message>
        <location filename="../geolib.py" line="253"/>
        <source>Delete selected feature</source>
        <translation type="obsolete">選択した地物を削除</translation>
    </message>
    <message>
        <location filename="../geolib.py" line="263"/>
        <source>Draw Strike Line</source>
        <translation type="obsolete">走向線を描画</translation>
    </message>
    <message>
        <location filename="../geolib.py" line="263"/>
        <source>Draw strike line based on selected point</source>
        <translation type="obsolete">選択した走向・傾斜をもとに走向線を描画</translation>
    </message>
    <message>
        <location filename="../geolib.py" line="297"/>
        <source>Export To Web Library</source>
        <translation type="obsolete">Webライブラリにエクスポート</translation>
    </message>
    <message>
        <location filename="../geolib.py" line="297"/>
        <source>Export to Web Geoscience Library</source>
        <translation type="obsolete">Web地学ライブラリにエクスポート</translation>
    </message>
    <message>
        <location filename="../geolib.py" line="310"/>
        <source>Settings</source>
        <translation type="obsolete">設定</translation>
    </message>
    <message>
        <location filename="../geolib.py" line="310"/>
        <source>Open settings dialog</source>
        <translation type="obsolete">設定ダイアログを開く</translation>
    </message>
    <message>
        <location filename="../geolib.py" line="320"/>
        <source>Geolib Help</source>
        <translation type="obsolete">ヘルプ</translation>
    </message>
    <message>
        <location filename="../geolib.py" line="320"/>
        <source>Open help file</source>
        <translation type="obsolete">ヘルプファイルを表示</translation>
    </message>
    <message>
        <location filename="../geolib.py" line="272"/>
        <source>Copy Features</source>
        <translation type="obsolete">地物のコピー</translation>
    </message>
    <message>
        <location filename="../geolib.py" line="272"/>
        <source>Copy selected features</source>
        <translation type="obsolete">選択した地物をコピー</translation>
    </message>
    <message>
        <location filename="../geolib.py" line="282"/>
        <source>Paste Features</source>
        <translation type="obsolete">地物の貼り付け</translation>
    </message>
    <message>
        <location filename="../geolib.py" line="282"/>
        <source>Paste copied features</source>
        <translation type="obsolete">コピーした地物を貼り付け</translation>
    </message>
    <message>
        <location filename="../geolib.py" line="510"/>
        <source>Feature not selected.Please select.</source>
        <translation>地物が選択されていません。選択してください。</translation>
    </message>
    <message>
        <location filename="../geolib.py" line="498"/>
        <source>The feature to be merged is not selected.Please select two or more features.</source>
        <translation>結合する地物が選択されていません。2つ以上の地物を選択してください。</translation>
    </message>
    <message>
        <location filename="../geolib.py" line="233"/>
        <source>Split feature</source>
        <translation type="obsolete">地物を分割</translation>
    </message>
    <message>
        <location filename="../geolib.py" line="70"/>
        <source>&amp;GeoscienceLibraryTool</source>
        <translation type="obsolete">&amp;地学ライブラリツール</translation>
    </message>
    <message>
        <location filename="../geolib.py" line="72"/>
        <source>GeoscienceLibraryTool</source>
        <translation type="obsolete">地学ライブラリツール</translation>
    </message>
</context>
<context>
    <name>GeolibUtil</name>
    <message>
        <location filename="../geolib_util.py" line="66"/>
        <source>Folder name or file name is not specified.</source>
        <translation>フォルダ名またはファイル名が指定されていません。</translation>
    </message>
    <message>
        <location filename="../geolib_util.py" line="75"/>
        <source>Folder name is not specified.</source>
        <translation>フォルダ名が指定されていません。</translation>
    </message>
</context>
<context>
    <name>HtmlEditDialog</name>
    <message>
        <location filename="../ui_html_edit_dialog.py" line="70"/>
        <source>Scenario Edit Dialog</source>
        <translation>シナリオ編集ダイアログ</translation>
    </message>
    <message>
        <location filename="../ui_html_edit_dialog.py" line="71"/>
        <source>Edit</source>
        <translation>編集</translation>
    </message>
    <message>
        <location filename="../ui_html_edit_dialog.py" line="72"/>
        <source>Close</source>
        <translation>閉じる</translation>
    </message>
    <message>
        <location filename="../ui_html_edit_dialog.py" line="73"/>
        <source>Path</source>
        <translation>シナリオフォルダ</translation>
    </message>
    <message>
        <location filename="../ui_html_edit_dialog.py" line="74"/>
        <source>File Name</source>
        <translation>テンプレートから作成</translation>
    </message>
    <message>
        <location filename="../ui_html_edit_dialog.py" line="75"/>
        <source>New</source>
        <translation>作成</translation>
    </message>
    <message>
        <location filename="../ui_html_edit_dialog.py" line="76"/>
        <source>Selected File Name</source>
        <translation>選択したファイル名</translation>
    </message>
    <message>
        <location filename="../ui_html_edit_dialog.py" line="77"/>
        <source>Preview</source>
        <translation>プレビュー</translation>
    </message>
    <message>
        <location filename="../ui_html_edit_dialog.py" line="78"/>
        <source>Explorer</source>
        <translation>フォルダ表示</translation>
    </message>
    <message>
        <location filename="../ui_html_edit_dialog.py" line="79"/>
        <source>.html</source>
        <translation>.html</translation>
    </message>
</context>
<context>
    <name>ImportGeoclinoDialog</name>
    <message>
        <location filename="../import_geoclino_dialog.py" line="91"/>
        <source>You must specify a GeoClino Data file to import</source>
        <translation>インポートするGeoClinoデータファイルを指定してください</translation>
    </message>
    <message>
        <location filename="../import_geoclino_dialog.py" line="94"/>
        <source>Cannot open file: </source>
        <translation>ファイルが開けません </translation>
    </message>
    <message>
        <location filename="../ui_import_geoclino_dialog.py" line="52"/>
        <source>Import GeoClino Data</source>
        <translation>Geoclinoデータをインポート</translation>
    </message>
    <message>
        <location filename="../ui_import_geoclino_dialog.py" line="53"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../ui_import_geoclino_dialog.py" line="54"/>
        <source>GeoClino Data File</source>
        <translation>GeoClinoデータファイル</translation>
    </message>
    <message>
        <location filename="../ui_import_geoclino_dialog.py" line="55"/>
        <source>Import</source>
        <translation>インポート</translation>
    </message>
    <message>
        <location filename="../ui_import_geoclino_dialog.py" line="56"/>
        <source>Cancel</source>
        <translation>キャンセル</translation>
    </message>
    <message>
        <location filename="../ui_import_geoclino_dialog.py" line="57"/>
        <source>Destination Layer</source>
        <translation>インポート先レイヤ</translation>
    </message>
    <message>
        <location filename="../import_geoclino_dialog.py" line="83"/>
        <source>The xml file name not been entered. Please enter.</source>
        <translation>XMLファイルを指定してください。</translation>
    </message>
</context>
<context>
    <name>SettingsDialog</name>
    <message>
        <location filename="../ui_settings_dialog.py" line="214"/>
        <source>Geoscience Library Tools Settings</source>
        <translation>設定</translation>
    </message>
    <message>
        <location filename="../ui_settings_dialog.py" line="215"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../ui_settings_dialog.py" line="216"/>
        <source>Cancel</source>
        <translation>キャンセル</translation>
    </message>
    <message>
        <location filename="../ui_settings_dialog.py" line="217"/>
        <source>External Tools</source>
        <translation>外部プログラム</translation>
    </message>
    <message>
        <location filename="../ui_settings_dialog.py" line="218"/>
        <source>...</source>
        <translation>....</translation>
    </message>
    <message>
        <location filename="../ui_settings_dialog.py" line="219"/>
        <source>HTML Editor</source>
        <translation>HTMLエディタ</translation>
    </message>
    <message>
        <location filename="../ui_settings_dialog.py" line="220"/>
        <source>Project Setting</source>
        <translation>プロジェクト設定</translation>
    </message>
    <message>
        <location filename="../ui_settings_dialog.py" line="221"/>
        <source>Strike Line</source>
        <translation>走向線</translation>
    </message>
    <message>
        <location filename="../ui_settings_dialog.py" line="222"/>
        <source>Contour interval (m)</source>
        <translation>等高線間隔(m)</translation>
    </message>
    <message>
        <location filename="../ui_settings_dialog.py" line="223"/>
        <source>Polyline interpolation tolerance in map units.</source>
        <translation>Polyline interpolation tolerance in map units.</translation>
    </message>
    <message>
        <location filename="../ui_settings_dialog.py" line="224"/>
        <source>Length of line (m)</source>
        <translation>走向線の長さ(m)</translation>
    </message>
    <message>
        <location filename="../ui_settings_dialog.py" line="225"/>
        <source>Number of line</source>
        <translation>走向線の数</translation>
    </message>
    <message>
        <location filename="../ui_settings_dialog.py" line="226"/>
        <source>Line width</source>
        <translation>線の幅</translation>
    </message>
    <message>
        <location filename="../ui_settings_dialog.py" line="227"/>
        <source>Show extension line</source>
        <translation>補助線を表示</translation>
    </message>
    <message>
        <location filename="../ui_settings_dialog.py" line="228"/>
        <source>Line Color</source>
        <translation>線の色</translation>
    </message>
    <message>
        <location filename="../ui_settings_dialog.py" line="229"/>
        <source>Line Color(High)</source>
        <translation>高位の線の色</translation>
    </message>
    <message>
        <location filename="../ui_settings_dialog.py" line="230"/>
        <source>Line Color(Low)</source>
        <translation>低位の線の色</translation>
    </message>
    <message>
        <location filename="../ui_settings_dialog.py" line="231"/>
        <source>R</source>
        <translation>赤</translation>
    </message>
    <message>
        <location filename="../ui_settings_dialog.py" line="232"/>
        <source>G</source>
        <translation>緑</translation>
    </message>
    <message>
        <location filename="../ui_settings_dialog.py" line="233"/>
        <source>B</source>
        <translation>青</translation>
    </message>
    <message>
        <location filename="../ui_settings_dialog.py" line="234"/>
        <source>Geological Map Setting</source>
        <translation>地質図設定</translation>
    </message>
    <message>
        <location filename="../ui_settings_dialog.py" line="235"/>
        <source>Geoscience Library Server</source>
        <translation>地学ライブラリサーバー</translation>
    </message>
    <message>
        <location filename="../ui_settings_dialog.py" line="236"/>
        <source>Server URL</source>
        <translation>サーバーURL</translation>
    </message>
    <message>
        <location filename="../ui_settings_dialog.py" line="237"/>
        <source>User ID (e-Mail Address)</source>
        <translation>ユーザーID（メールアドレス）</translation>
    </message>
    <message>
        <location filename="../ui_settings_dialog.py" line="238"/>
        <source>Password</source>
        <translation>パスワード</translation>
    </message>
    <message>
        <location filename="../ui_settings_dialog.py" line="239"/>
        <source>Geolib Setting</source>
        <translation>地学ライブラリ設定</translation>
    </message>
</context>
</TS>
