# -*- coding: utf-8 -*-
"""
geolib.py
    Created                : 2018-07-05
    copyright         : (C) 2018 Dank Co., Ltd.
    email                : yukihiko.karata@nsb-dank.com
/***************************************************************************
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 ***************************************************************************/
 This script initializes the plugin, making it known to QGIS.
"""

from qgis.PyQt.QtCore import  QSettings, QTranslator, qVersion, QCoreApplication,QVariant
from qgis.PyQt.QtGui import QIcon, QColor
from qgis.PyQt.QtWidgets import QAction,QMenu,QToolButton,QMessageBox
from qgis.core import  QgsApplication, \
                                QgsProject, \
                                QgsMapLayer, \
                                QgsWkbTypes, \
                                QgsPoint,QgsGeometry, \
                                QgsSimpleMarkerSymbolLayer, \
                                QgsSvgMarkerSymbolLayer, \
                                QgsSimpleLineSymbolLayer, \
                                QgsSimpleFillSymbolLayer
from qgis.gui import QgsRubberBand
import math

import os.path
import shutil
from distutils import dir_util
from .geolib_util import GeolibUtil

class Geolib:

    def __init__(self, iface):
        self.iface = iface
        self.canvas = self.iface.mapCanvas()
        self.plugin_dir = os.path.dirname(__file__)
        locale = QSettings().value("locale/userLocale")[0:2]
        locale_path = os.path.join(
            self.plugin_dir,
            'i18n',
            'geolib_{}.qm'.format(locale))
        if os.path.exists(locale_path):
            self.translator = QTranslator()
            self.translator.load(locale_path)
            if qVersion() > '4.3.3':
                QCoreApplication.installTranslator(self.translator)

        #Initial Settings
        self.settings = QSettings()
        self.editor_program = self.settings.value("geolib/editorProgram","")
        self.contour_interval = self.settings.value("geolib/contourInterval", 10)
        self.strike_line_length = self.settings.value("geolib/strikeLineLength" , 5000)
        self.strike_line_num = self.settings.value("geolib/strikeLineNum", 10)
        self.line_width= self.settings.value("geolib/LineWidth", 3)
        self.line_color_R = self.settings.value("geolib/LineColorR",255)
        self.line_color_G = self.settings.value("geolib/LineColorG",128)
        self.line_color_B = self.settings.value("geolib/LineColorB",0)
        self.line_color_HR = self.settings.value("geolib/LineColorHR",255)
        self.line_color_HG = self.settings.value("geolib/LineColorHG",0)
        self.line_color_HB = self.settings.value("geolib/LineColorHB",0)
        self.line_color_LR = self.settings.value("geolib/LineColorLR",0)
        self.line_color_LG = self.settings.value("geolib/LineColorLG",0)
        self.line_color_LB = self.settings.value("geolib/LineColorLB",255)
        self.show_ext_line = self.settings.value("geolib/ShowExtLine",True)
        self.server_url = self.settings.value("geolib/serverUrl","http://localhost/geolib")
        self.user_id = self.settings.value("geolib/userId","test@test.com")
        self.password = self.settings.value("geolib/password","test")

        #templateのsvgファイルをQGISのsvgフォルダにコピー
        geolib = GeolibUtil()
        svgPath = os.path.join(QgsApplication.prefixPath(),'svg','geolib').replace('/','\\')
        templatePath = os.path.join(GeolibUtil.pluginpath,'template','svg').replace('/','\\')
        geolib.createFolder(svgPath)
        dir_util.copy_tree(templatePath, svgPath)

        # Declare instance attributes
        self.actions = []
        self.menu = QMenu(u'&地学ライブラリツール')
        self.toolbar = self.iface.addToolBar(u'地学ライブラリツール')
        self.toolbar.setObjectName(u'GeoscienceLibraryTool')

        self.pluginIsActive = False
        self.iface.currentLayerChanged.connect(self.currentLayerChanged)
        self.qgsProject = QgsProject.instance()
        self.qgsProject.layersAdded.connect(self.currentLayerChanged)
        # check currently selected layer
        self.currentlayer = None
        #self.currentLayerChanged()

    def tr(self, message):
        return QCoreApplication.translate('geolib', message)

    def add_action(
        self,
        icon_path,
        text,
        callback,
        enabled_flag=True,
        status_tip=None,
        whats_this=None,
        checkable=False,
        shortcut=None,
        parent = None):
        icon = QIcon(icon_path)
        action = QAction(icon, text ,parent)
        action.triggered.connect(callback)
        action.setEnabled(enabled_flag)
        if checkable:
            action.setCheckable(True)
        if status_tip is not None:
            action.setStatusTip(status_tip)
        if whats_this is not None:
            action.setWhatsThis(whats_this)
        if shortcut:
            action.setShortcut(shortcut)
        self.actions.append(action)
        return action

    def initGui(self):
        #プロジェクトツール --------
        self.menuProjectTool = QMenu(u'プロジェクトツール')
        self.menu.addMenu(self.menuProjectTool)
        self.toolProjectTool = QToolButton()
        self.toolProjectTool.setIcon(QIcon(os.path.join(self.plugin_dir, 'icons', 'project_tool.png')))
        self.toolProjectTool.setMenu(self.menuProjectTool)
        self.toolProjectTool.setPopupMode(QToolButton.InstantPopup)
        self.toolbar.addWidget(self.toolProjectTool)
        #新規プロジェクト
        self.actionNewProject = self.add_action(
                        os.path.join(self.plugin_dir, 'icons', 'new.png'),
                        text=u'新規プロジェクト作成',
                        callback=self.newProject,
                        status_tip=u'新規プロジェクトを作成します',
                        checkable=False,
                        enabled_flag=True
                        )
        self.menuProjectTool.addAction(self.actionNewProject)
        #self.toolbar.addAction(self.actionNewProject)
        #プロジェクトを開く
        self.actionOpenProject = self.add_action(os.path.join(self.plugin_dir, 'icons', 'open.png'),
                        text=u'プロジェクトを開く',
                        callback=self.openProject,
                        status_tip=u'QGISプロジェクトファイルを選択して開きます',
                        checkable=False,
                        enabled_flag=True
                        )
        self.menuProjectTool.addAction(self.actionOpenProject)
        #self.toolbar.addAction(self.actionOpenProject)

        #レイヤーツール -------
        self.toolbar.addSeparator()
        self.menu.addSeparator()
        self.menuLayerTool = QMenu(u'レイヤーツール')
        self.menu.addMenu(self.menuLayerTool)
        self.toolLayerTool = QToolButton()
        self.toolLayerTool.setIcon(QIcon(os.path.join(self.plugin_dir, 'icons', 'layer_tool.png')))
        self.toolLayerTool.setMenu(self.menuLayerTool)
        self.toolLayerTool.setPopupMode(QToolButton.InstantPopup)
        self.toolbar.addWidget(self.toolLayerTool)
        #レイヤグループの追加
        self.actionAddGroup = self.add_action(os.path.join(self.plugin_dir, 'icons', 'add_group.png'),
                        text=u'レイヤーグループの作成',
                        callback=self.addGroup,
                        status_tip=u'レイヤーグループを作成します',
                        checkable=False,
                        enabled_flag=True
                        )
        self.menuLayerTool.addAction(self.actionAddGroup)
        #シナリオ編集
        self.actionEditHtml = self.add_action(os.path.join(self.plugin_dir, 'icons', 'edit_html.png'),
                        text=u'シナリオコンテンツの編集',
                        callback=self.editHtml,
                        status_tip=u'シナリオコンテンツを編集します',
                        checkable=False,
                        enabled_flag=True
                        )
        self.menuLayerTool.addAction(self.actionEditHtml)
        #Geoclinoからインポート
        self.actionImportGeoclino = self.add_action(os.path.join(self.plugin_dir, 'icons', 'import_geoclino.png'),
                        text=u'Geoclino データのインポート',
                        callback=self.importGeoclino,
                        status_tip=u'Geoclino for iPhone の XMLデータをインポートします',
                        checkable=False,
                        enabled_flag=True
                        )
        self.menuLayerTool.addAction(self.actionImportGeoclino)
        #編集ツール -------
        self.toolbar.addSeparator()
        self.menu.addSeparator()
        #レイヤ保存
        self.actionSaveLayer = self.add_action(os.path.join(self.plugin_dir, 'icons', 'save.png'),
                        text=u'レイヤーデータの保存',
                        callback=self.saveLayer,
                        status_tip=u'選択したレイヤーのデータを最新化します',
                        checkable=False,
                        enabled_flag=True
                        )
        self.menu.addAction(self.actionSaveLayer)
        self.toolbar.addAction(self.actionSaveLayer)
        #地物属性の編集
        self.actionEditAttribute = self.add_action(os.path.join(self.plugin_dir, 'icons', 'edit_attribute.png'),
                        text=u'地物属性の編集',
                        callback=self.editAttribute,
                        status_tip=u'選択中の地物の属性編集ダイアログを開きます',
                        checkable=False,
                        enabled_flag=True
                        )
        self.menu.addAction(self.actionEditAttribute)
        self.toolbar.addAction(self.actionEditAttribute)
        #地物の追加
        self.actionAddFeature = self.add_action(os.path.join(self.plugin_dir, 'icons', 'add_feature.png'),
                        text=u'地物の追加',
                        callback=self.addFeature,
                        status_tip=u'アクティブなレイヤーに地物を追加します',
                        checkable=True,
                        enabled_flag=True
                        )
        self.menu.addAction(self.actionAddFeature)
        self.toolbar.addAction(self.actionAddFeature)
        #地物の移動
        self.actionMoveFeature = self.add_action(os.path.join(self.plugin_dir, 'icons', 'move_feature.png'),
                        text=u'地物の移動',
                        callback=self.moveFeature,
                        status_tip=u'地物を選択してします',
                        checkable=True,
                        enabled_flag=True
                        )
        self.menu.addAction(self.actionMoveFeature)
        self.toolbar.addAction(self.actionMoveFeature)
        #ノード編集
        self.actionEditNode = self.add_action(os.path.join(self.plugin_dir, 'icons', 'edit_node.png'),
                        text=u'ノードの編集',
                        callback=self.editNode,
                        status_tip=u'ノードを追加・移動・編集します',
                        checkable=True,
                        enabled_flag=True
                        )
        self.menu.addAction(self.actionEditNode)
        self.toolbar.addAction(self.actionEditNode)
        #地物の分割
        self.actionSplitFeature = self.add_action(os.path.join(self.plugin_dir, 'icons', 'split_feature.png'),
                        text=u'地物の分割',
                        callback=self.splitFeature,
                        status_tip=u'地物を分割します',
                        checkable=True,
                        enabled_flag=True
                        )
        self.menu.addAction(self.actionSplitFeature)
        self.toolbar.addAction(self.actionSplitFeature)
        #地物の結合
        self.actionMergeFeatures = self.add_action(os.path.join(self.plugin_dir, 'icons', 'merge_features.png'),
                        text=u'地物の結合',
                        callback=self.mergeFeatures,
                        status_tip=u'選択している複数の地物を結合します',
                        checkable=False,
                        enabled_flag=True
                        )
        self.menu.addAction(self.actionMergeFeatures)
        self.toolbar.addAction(self.actionMergeFeatures)
        #地物の削除
        self.actionDeleteFeature = self.add_action(os.path.join(self.plugin_dir, 'icons', 'delete.png'),
                        text=u'地物の削除',
                        callback=self.deleteFeature,
                        status_tip=u'選択している地物を削除します',
                        checkable=False,
                        enabled_flag=True
                        )
        self.menu.addAction(self.actionDeleteFeature)
        self.toolbar.addAction(self.actionDeleteFeature)
        #走向線の描画
        self.actionDrawStrike = self.add_action(os.path.join(self.plugin_dir, 'icons', 'draw_trend.png'),
                        text=u'走向線の描画',
                        callback=self.drawStrike,
                        status_tip=u'選択している走向・傾斜をもとに走向線を描画します',
                        checkable=True,
                        enabled_flag=True)
        self.menu.addAction(self.actionDrawStrike)
        self.toolbar.addAction(self.actionDrawStrike)
        #地物のコピー
        self.actionCopyFeatures = self.add_action(os.path.join(self.plugin_dir, 'icons', 'copy_features.png'),
                        text=u'地物のコピー',
                        callback=self.copyFeatures,
                        status_tip=u'選択した地物をクリップボードにコピーします',
                        checkable=False,
                        enabled_flag=True
                        )
        self.menu.addAction(self.actionCopyFeatures)
        self.toolbar.addAction(self.actionCopyFeatures)
        #地物のペースト
        self.actionPasteFeatures = self.add_action(os.path.join(self.plugin_dir, 'icons', 'paste_features.png'),
                        text=u'地物の貼り付け',
                        callback=self.pasteFeatures,
                        status_tip=u'クリップボードにある地物をアクティブなレイヤーに貼り付けます',
                        checkable=False,
                        enabled_flag=True
                        )
        self.menu.addAction(self.actionPasteFeatures)
        self.toolbar.addAction(self.actionPasteFeatures)

        # -------------------------------------------------------------
        #オプション -------
        self.toolbar.addSeparator()
        self.menu.addSeparator()
        #データエクスポート
        self.actionExportData = self.add_action(os.path.join(self.plugin_dir, 'icons', 'export_data.png'),
                        text=u'Webライブラリにエクスポート',
                        callback=self.exportData,
                        status_tip=u'Web地学ライブラリにデータをエクスポートします',
                        checkable=False,
                        enabled_flag=True
                        )
        self.menu.addAction(self.actionExportData)
        self.toolbar.addAction(self.actionExportData)

        self.toolbar.addSeparator()
        self.menu.addSeparator()
        #設定を開く
        self.actionOpenSettings = self.add_action(os.path.join(self.plugin_dir, 'icons', 'settings.png'),
                        text=u'設定',
                        callback=self.openSettings,
                        status_tip=u'設定ダイアログを開きます',
                        checkable=False,
                        enabled_flag=True
                        )
        self.menu.addAction(self.actionOpenSettings)
        self.toolbar.addAction(self.actionOpenSettings)
        #ヘルプを開く
        self.actionOpenHelp = self.add_action(os.path.join(self.plugin_dir, 'icons', 'help.png'),
                        text=u'Geolib ヘルプ',
                        callback=self.openHelp,
                        status_tip=u'ヘルプファイルを開きます」',
                        checkable=False,
                        enabled_flag=True
                        )
        self.menu.addAction(self.actionOpenHelp)
        self.toolbar.addAction(self.actionOpenHelp)

    #--------------------------------------------------------------------------

        menu_bar = self.iface.mainWindow().menuBar()
        actions = menu_bar.actions()
        lastAction = actions[ len( actions ) - 1 ]
        menu_bar.insertMenu( lastAction, self.menu )

    def onClosePlugin(self):
        self.pluginIsActive = False

    def unload(self):
        """Removes the plugin menu item and icon from QGIS GUI."""

        for action in self.actions:
            #self.iface.removePluginMenu(
            #    self.tr(u'&Geoscience Library Tool'),
            #    action)
            self.iface.removeToolBarIcon(action)
        # remove the toolbar
        del self.toolbar
        del self.menu

        self.iface.currentLayerChanged.disconnect(self.currentLayerChanged)
        self.qgsProject.layersAdded.disconnect(self.currentLayerChanged)

    #--------------------------------------------------------------------------

    def run(self):
        """Run method that loads and starts the plugin"""
        if not self.pluginIsActive:
            self.pluginIsActive = True

    #--------------------------------------------------------------------------
    # メニューアクション定義
    #--------------------------------------------------------------------------
    def newProject(self):
        #　新規プロジェクト作成ダイアログを開く
        from .create_project_dialog import CreateProjectDialog
        dlg = CreateProjectDialog(self.iface)
        dlg.show()
        dlg.exec_()

    def openProject(self):
        #プロジェクトを開く
        self.iface.actionOpenProject().trigger()

    def exportData(self):
        #データエクスポートダイアログを開く
        from .export_to_geolib_dialog import ExportToGeolibDialog
        dlg = ExportToGeolibDialog(self.iface)
        dlg.show()
        dlg.exec_()

    def addGroup(self):
        #新規グループ作成ダイアログを開く
        from .create_layer_group_dialog import CreateLayerGroupDialog
        dlg = CreateLayerGroupDialog(self.iface)
        dlg.show()
        dlg.exec_()

    def editHtml(self):
        #HTML編集ダイアログを開く
        from .html_edit_dialog import HtmlEditDialog
        dlg = HtmlEditDialog(self.iface)
        dlg.show()
        dlg.exec_()

    def importGeoclino(self):
        #Geolicinoデータインポートダイアログを開く
        from .import_geoclino_dialog import ImportGeoclinoDialog
        dlg = ImportGeoclinoDialog(self.iface)
        dlg.show()
        dlg.exec_()

    def saveLayer(self):
        #アクティブレイヤーデータを保存する
        self.updateFeatureAttribute()

    def addFeature(self):
        #地物追加モードにする
        layer = self.iface.activeLayer()
        if self.actionAddFeature.isChecked():
            self.actionEditNode.setChecked(False)
            self.actionMoveFeature.setChecked(False)
            self.actionSplitFeature.setChecked(False)
            layer.startEditing()
            self.iface.actionAddFeature().trigger()
        else:
            layer.commitChanges()
            layer.endEditCommand()

    def editAttribute(self):
        #地物属性編集ダイアログを開く
        from .edit_attribute_dialog import EditAttributeDialog
        layer = self.iface.activeLayer()
        feats_count = layer.selectedFeatureCount()
        if feats_count >0:
            dlg = EditAttributeDialog(self.iface)
            dlg.show()
            dlg.exec_()
        else:
            QMessageBox.information(None, "Infoemation:", self.tr("Feature not selected.Please select."))

    def moveFeature(self):
        #地物移動モードにする
        layer = self.iface.activeLayer()
        if self.actionMoveFeature.isChecked():
            self.actionAddFeature.setChecked(False)
            self.actionEditNode.setChecked(False)
            self.actionSplitFeature.setChecked(False)

            layer.startEditing()
            self.iface.actionMoveFeature().trigger()
        else:
            layer.commitChanges()
            layer.endEditCommand()

    def editNode(self):
        #ノード編集モードにする
        layer = self.iface.activeLayer()
        if self.actionEditNode.isChecked():
            self.actionAddFeature.setChecked(False)
            self.actionMoveFeature.setChecked(False)
            self.actionSplitFeature.setChecked(False)

            layer.startEditing()
            self.iface.actionVertexTool().trigger()
        else:
            layer.commitChanges()
            layer.endEditCommand()

    def splitFeature(self):
        #地物分割ツールを起動する
        layer = self.iface.activeLayer()
        if self.actionSplitFeature.isChecked():
            self.actionAddFeature.setChecked(False)
            self.actionEditNode.setChecked(False)
            self.actionMoveFeature.setChecked(False)

            layer.startEditing()
            self.iface.actionSplitFeatures().trigger()
        else:
            layer.commitChanges()
            layer.endEditCommand()

    def mergeFeatures(self):
        #地物結合ツールを起動する
        layer = self.iface.activeLayer()
        feats_count = layer.selectedFeatureCount()
        if feats_count >1:
            layer.startEditing()
            self.iface.mainWindow().findChild( QAction, 'mActionMergeFeatures' ).trigger()
            layer.commitChanges()
            layer.endEditCommand()
        else:
            QMessageBox.information(None, "Infoemation:", self.tr("The feature to be merged is not selected.Please select two or more features."))

    def deleteFeature(self):
        #地物削除ツールを起動する
        layer = self.iface.activeLayer()
        feats_count = layer.selectedFeatureCount()
        if feats_count >0:
            layer.startEditing()
            self.iface.actionDeleteSelected().trigger()
            layer.commitChanges()
            layer.endEditCommand()
        else:
            QMessageBox.information(None, "Infoemation:", self.tr("Feature not selected.Please select."))

    def drawStrike(self):
        #走向線を引く
        self.drawStrikeExecution()

    def copyFeatures(self):
        #地物コピーツールを起動する
        layer = self.iface.activeLayer()
        layer.startEditing()
        self.iface.actionCopyFeatures().trigger()
        layer.commitChanges()
        layer.endEditCommand()

    def pasteFeatures(self):
        #地物ペーストツールを起動する
        layer = self.iface.activeLayer()
        layer.startEditing()
        self.iface.actionPasteFeatures().trigger()
        layer.commitChanges()
        layer.endEditCommand()

    def openSettings(self):
        #設定ダイアログを開く
        from .settings_dialog import SettingsDialog
        dlg = SettingsDialog(self.iface)
        dlg.show()
        dlg.exec_()

    def  openHelp(self):
        #ヘルプを開く
        import webbrowser
        webbrowser.open(self.plugin_dir + "/help/geolib_help.pdf")


    def currentLayerChanged(self):
        #if self.currentlayer is not None:
        #    self.currentlayer.editingStarted.disconnect(self.curLayerIsEditable)
        #    self.currentlayer.editingStopped.disconnect(self.curLayerIsNotEditable)
        project = QgsProject.instance().fileName()
        if len(project) >0:
            layer = self.iface.activeLayer()
            self.actionExportData.setEnabled(True)
            if layer is not None and layer.type() == QgsMapLayer.VectorLayer:
                self.currentlayer = layer
                self.iface.actionSelect().trigger()
                #action 活性化
                self.actionSaveLayer.setEnabled(True)
                self.actionEditAttribute.setEnabled(True)
                self.actionAddFeature.setEnabled(True)
                self.actionMoveFeature.setEnabled(True)
                self.actionEditNode.setEnabled(True)
                self.actionSplitFeature.setEnabled(True)
                self.actionMergeFeatures.setEnabled(True)
                self.actionDeleteFeature.setEnabled(True)
                self.actionDrawStrike.setEnabled(True)
                self.actionCopyFeatures.setEnabled(True)
                self.actionPasteFeatures.setEnabled(True)


                #if layer.type() != QgsMapLayer.VectorLayer:
                #    layer = None
                #elif layer.geometryType() != QgsWkbTypes.LineGeometry:
                #    layer = None
            else:
                #action 非活性化
                self.actionSaveLayer.setEnabled(False)
                self.actionEditAttribute.setEnabled(False)
                self.actionAddFeature.setEnabled(False)
                self.actionMoveFeature.setEnabled(False)
                self.actionEditNode.setEnabled(False)
                self.actionSplitFeature.setEnabled(False)
                self.actionMergeFeatures.setEnabled(False)
                self.actionDeleteFeature.setEnabled(False)
                self.actionDrawStrike.setEnabled(False)
                self.actionCopyFeatures.setEnabled(False)
                self.actionPasteFeatures.setEnabled(False)

        else:
            self.actionExportData.setEnabled(False)

        #if layer is not None:
            #self.iface.mainWindow().findChild( QAction, 'mActionSelectFeatures' ).trigger()
            #layer.editingStarted.connect(self.curLayerIsEditable)
            #layer.editingStopped.connect(self.curLayerIsNotEditable)

        #   if layer.isEditable():  # in case an editable layer is selected
        #        self.curLayerIsEditable()
        #    else:
        #        self.curLayerIsNotEditable()
        #else:
        #    self.curLayerIsNotEditable()



    def curLayerIsEditable(self):
        layer = self.iface.activeLayer()
        for act in self.actions:
            act.setEnabled(True)
        #if layer.wkbType() == QGis.WKBLineString25D or layer.wkbType() == QGis.WKBMultiLineString25D:
        #    self.actions[0].setEnabled(False)
        #    self.actions[1].setEnabled(False) # disallow z-breaking operations on 3d layers

    def curLayerIsNotEditable(self):
        self.iface.actionPan().trigger()
        for act in self.actions:
            act.setEnabled(False)


    # 走向線描画

    def drawStrikeExecution(self):
        self.layer = self.iface.activeLayer()
        if  self.actionDrawStrike.isChecked():
            self.features = self.layer.selectedFeatures()

            if len(self.features) > 0:
                feature = self.features[0]
                self.p1 = feature.geometry().asMultiPoint()[0]

                # 設定値をセット
                self.settings = QSettings()
                self.contour_interval = float(self.settings.value("geolib/contourInterval", 10))
                self.strike_line_length = float(self.settings.value("geolib/strikeLineLength" , 5000))
                self.strike_line_num = int(self.settings.value("geolib/strikeLineNum", 10))
                self.line_width= int(self.settings.value("geolib/LineWidth", 3))
                self.line_color_R = int(self.settings.value("geolib/LineColorR",255))
                self.line_color_G = int(self.settings.value("geolib/LineColorG",128))
                self.line_color_B = int(self.settings.value("geolib/LineColorB",0))
                self.line_color_HR = int(self.settings.value("geolib/LineColorHR",255))
                self.line_color_HG = int(self.settings.value("geolib/LineColorHG",0))
                self.line_color_HB = int(self.settings.value("geolib/LineColorHB",0))
                self.line_color_LR = int(self.settings.value("geolib/LineColorLR",0))
                self.line_color_LG = int(self.settings.value("geolib/LineColorLG",0))
                self.line_color_LB = int(self.settings.value("geolib/LineColorLB",255))
                self.show_ext_line = self.settings.value("geolib/ShowExtLine",True)

                self.length = float(self.strike_line_length)  * 0.00001  # 走向線の長さ
                self.interval = float(self.contour_interval) * 0.00001      #等高線の間隔
                self.strike = float(feature["strike_value"])
                self.dip = float(feature["dip_value"])
                if self.dip != 0:
                    self.dist = self.interval / math.tan(math.radians(self.dip))
                else:
                    self.dist = self.interval

                #始点と終点を指定
                msx = self.p1.x() + self.length*math.sin(math.radians(self.strike))
                msy = self.p1.y() + self.length*math.cos(math.radians(self.strike))
                mex = self.p1.x() - self.length*math.sin(math.radians(self.strike))
                mey = self.p1.y() - self.length*math.cos(math.radians(self.strike))
                ms = QgsPoint(msx,msy)
                me = QgsPoint(mex,mey)
                line = QgsGeometry.fromPolyline([ms, me])

                #ラバーバンドにラインを描画
                #self.layer = self.iface.activeLayer()
                if self.layer is not None:
                    self.rubber = QgsRubberBand(self.canvas, QgsWkbTypes.LineGeometry)
                    self.rubber.setColor(QColor(self.line_color_R, self.line_color_G, self.line_color_B, 100))
                    self.rubber.setWidth(self.line_width)
                    self.rubber.reset(QgsWkbTypes.LineGeometry)
                    self.rubber.addGeometry(line,self.layer)

                    # 走向線を描画
                    self.rubberH = QgsRubberBand(self.canvas, QgsWkbTypes.LineGeometry)
                    self.rubberH.setColor(QColor(self.line_color_HR, self.line_color_HG, self.line_color_HB, 100))
                    self.rubberH.setWidth(self.line_width)
                    self.rubberL = QgsRubberBand(self.canvas, QgsWkbTypes.LineGeometry)
                    self.rubberL.setColor(QColor(self.line_color_LR, self.line_color_LG, self.line_color_LB, 100))
                    self.rubberL.setWidth(self.line_width)

                    for i in range(self.strike_line_num):
                        d = i + 1
                        nx = self.p1.x() + self.dist * d * math.sin(math.radians(self.strike + 90))
                        ny = self.p1.y() + self.dist * d * math.cos(math.radians(self.strike + 90))
                        nsx = nx + self.length*math.sin(math.radians(self.strike))
                        nsy = ny + self.length*math.cos(math.radians(self.strike))
                        nex = nx - self.length*math.sin(math.radians(self.strike))
                        ney = ny - self.length*math.cos(math.radians(self.strike))

                        ns = QgsPoint(nsx, nsy)
                        ne = QgsPoint(nex, ney)

                        line = QgsGeometry.fromPolyline([ns, ne])
                        self.rubberL.addGeometry(line,self.layer)

                        nx = self.p1.x() - self.dist * d * math.sin(math.radians(self.strike + 90))
                        ny = self.p1.y() - self.dist * d * math.cos(math.radians(self.strike + 90))
                        nsx = nx + self.length*math.sin(math.radians(self.strike))
                        nsy = ny + self.length*math.cos(math.radians(self.strike))
                        nex = nx - self.length*math.sin(math.radians(self.strike))
                        ney = ny - self.length*math.cos(math.radians(self.strike))
                        ns = QgsPoint(nsx, nsy)
                        ne = QgsPoint(nex, ney)

                        line = QgsGeometry.fromPolyline([ns, ne])
                        self.rubberH.addGeometry(line,self.layer)

                    #補助走向線を描画
                    self.rubberEH = QgsRubberBand(self.canvas, QgsWkbTypes.LineGeometry)
                    self.rubberEH.setColor(QColor(self.line_color_HR, self.line_color_HG, self.line_color_HB, 100))
                    self.rubberEH.setWidth(1)
                    self.rubberEL = QgsRubberBand(self.canvas, QgsWkbTypes.LineGeometry)
                    self.rubberEL.setColor(QColor(self.line_color_LR, self.line_color_LG, self.line_color_LB, 100))
                    self.rubberEL.setWidth(1)

                    if self.show_ext_line == True:
                        for i in range(self.strike_line_num):
                            d = i + 1 - 0.5
                            nx = self.p1.x() + self.dist * d * math.sin(math.radians(self.strike + 90))
                            ny = self.p1.y() + self.dist * d * math.cos(math.radians(self.strike + 90))
                            nsx = nx + self.length*math.sin(math.radians(self.strike))
                            nsy = ny + self.length*math.cos(math.radians(self.strike))
                            nex = nx - self.length*math.sin(math.radians(self.strike))
                            ney = ny - self.length*math.cos(math.radians(self.strike))

                            ns = QgsPoint(nsx, nsy)
                            ne = QgsPoint(nex, ney)

                            line = QgsGeometry.fromPolyline([ns, ne])
                            self.rubberEL.addGeometry(line,self.layer)

                            nx = self.p1.x() - self.dist * d * math.sin(math.radians(self.strike + 90))
                            ny = self.p1.y() - self.dist * d * math.cos(math.radians(self.strike + 90))
                            nsx = nx + self.length*math.sin(math.radians(self.strike))
                            nsy = ny + self.length*math.cos(math.radians(self.strike))
                            nex = nx - self.length*math.sin(math.radians(self.strike))
                            ney = ny - self.length*math.cos(math.radians(self.strike))
                            ns = QgsPoint(nsx, nsy)
                            ne = QgsPoint(nex, ney)

                            line = QgsGeometry.fromPolyline([ns, ne])
                            self.rubberEH.addGeometry(line,self.layer)
            else:
                QMessageBox.information(None, "Infoemation:", self.tr("Feature not selected.Please select."))
                self.actionDrawStrike.setChecked(False)

        else:
            self.rubber.reset()
            self.rubberH.reset()
            self.rubberL.reset()
            self.rubberEH.reset()
            self.rubberEL.reset()

    def updateFeatureAttribute(self):
    #選択レイヤの地物のスタイル属性を一括更新
        layer = self.iface.activeLayer()
        layerName = layer.name()

        #シンボルレンダラを取得
        renderer = layer.renderer()
        categories = renderer.categories()
        # SVGマーカーの場合はstyleフォルダにSVGを保存
        project_folder, _ = os.path.splitext(QgsProject.instance().fileName())
        style_path = os.path.join(project_folder, "style")
        for category in categories:
            if ( type(category.symbol().symbolLayer(0)) == QgsSvgMarkerSymbolLayer):
                source_file = category.symbol().symbolLayer(0).path()
                svg_filename = os.path.basename(source_file)
                shutil.copyfile(source_file,os.path.join(style_path,svg_filename))

        #選択レイヤの地物のシンボル属性を取得してスタイル属性を更新
        layer.startEditing()
        features = layer.getFeatures()
        for feature in features:
            attr = ''
            # pntレイヤ
            if layerName.find('pnt')>-1:
                attr = feature['attribute']
            # strdipレイヤ
            elif layerName.find('strdip')>-1:
                attr = feature['attribute']
            # Geo_Lレイヤ
            elif layerName.find('geo_L')>1:
                attr = feature['major_code']
            # Geo_Aレイヤ
            elif layerName.find('geo_A')>1:
                attr = feature['symbol']
            # Scenarioレイヤ
            else:
                attr = feature['symbol']

            #スタイル属属性の初期化
            _markerType = ""
            _className = ""
            _stroke = "True"
            _color = ""
            _weight = ""
            _opacity = ""
            _fillOpacity = ""
            _fill = ""
            _fillColor = ""
            _dashArray =""
            _lineCap ="round"
            _lineJoin = "round"
            _clickable = "True"
            _iconUrl =""
            _iconSize = ""
            _iconAnchor = ""
            _iconSize = ""
            _html = ""
            _radius =""

            for category in categories:
                if category.value() == attr:
                    #選択したスタイル属性を取得
                    _className = category.label()
                    symbol = category.symbol().symbolLayer(0)
                    if(type(symbol) == QgsSimpleFillSymbolLayer):           #塗りつぶしマーカーの場合
                        _markerType = ""
                        _weight = str(symbol.strokeWidth())
                        _fill = "true"
                        if symbol.strokeStyle()==0:
                            _stroke = "false"
                        _opacity = "0.0"
                        _fillOpacity = "0.5"
                        _color = symbol.strokeColor().name()
                        _fillColor = symbol.fillColor().name()
                    if(type(symbol) == QgsSimpleLineSymbolLayer):         #ラインマーカーの場合
                        _markerType = ""
                        _weight = str(symbol.width())
                        _stroke = "True"
                        _opacity = "0.5"
                        _fillOpacity = ""
                        _color = symbol.color().name()
                        if symbol.penStyle() != 1:
                            _dashArray = "5,10"
                    if(type(symbol) == QgsSvgMarkerSymbolLayer):          #SVGマーカーの場合
                        _markerType = "Icon"
                        _iconSize = "[20,20]"
                        _iconUrl = os.path.basename(symbol.path())
                        #SVGの場合はstyleフォルダにコピー

                    if(type(symbol) == QgsSimpleMarkerSymbolLayer):     #シンプルマーカーの場合
                        _markerType = "Circle"
                        _weight = "1"
                        _color = symbol.strokeColor().name()
                        _fillColor = symbol.color().name()
                        _radius = str(symbol.size())

            #スタイル属性をセット
            feature['_markerType'] = _markerType
            feature['_className'] = _className
            feature['_stroke'] = _stroke
            feature['_color'] = _color
            feature['_weight'] = _weight
            feature['_opacity'] = _opacity
            #self.feature['_fillOpacity'] = self._opacity
            feature['_fill'] = _fill
            feature['_fillColor'] = _fillColor
            feature['_dashArray'] = _dashArray
            feature['_lineCap'] = _lineCap
            feature['_lineJoin'] = _lineJoin
            feature['_clickable'] = _clickable
            feature['_iconUrl'] = _iconUrl
            feature['_iconSize'] = _iconSize
            feature['_iconAnchor'] = _iconAnchor
            feature['_iconSize'] = _iconSize
            feature['_html'] = _html
            feature['_radius'] = _radius

            layer.updateFeature(feature)
        #Call commit to save the changes
        layer.commitChanges()


