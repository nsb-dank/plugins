# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui_create_layer_group_dialog.ui'
#
# Created by: PyQt5 UI code generator 5.9
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_CreateLayerGroupDialog(object):
    def setupUi(self, CreateLayerGroupDialog):
        CreateLayerGroupDialog.setObjectName("CreateLayerGroupDialog")
        CreateLayerGroupDialog.resize(540, 286)
        self.lblGroupFolder = QtWidgets.QLabel(CreateLayerGroupDialog)
        self.lblGroupFolder.setGeometry(QtCore.QRect(10, 160, 141, 21))
        self.lblGroupFolder.setObjectName("lblGroupFolder")
        self.txtGeoPackageName = QtWidgets.QLineEdit(CreateLayerGroupDialog)
        self.txtGeoPackageName.setGeometry(QtCore.QRect(160, 160, 171, 21))
        self.txtGeoPackageName.setStyleSheet("background-color: #fff79a")
        self.txtGeoPackageName.setInputMethodHints(QtCore.Qt.ImhLatinOnly)
        self.txtGeoPackageName.setObjectName("txtGeoPackageName")
        self.btnCreate = QtWidgets.QPushButton(CreateLayerGroupDialog)
        self.btnCreate.setGeometry(QtCore.QRect(320, 210, 93, 28))
        self.btnCreate.setObjectName("btnCreate")
        self.btnCancel = QtWidgets.QPushButton(CreateLayerGroupDialog)
        self.btnCancel.setGeometry(QtCore.QRect(420, 210, 93, 28))
        self.btnCancel.setObjectName("btnCancel")
        self.txtGroupName = QtWidgets.QLineEdit(CreateLayerGroupDialog)
        self.txtGroupName.setGeometry(QtCore.QRect(160, 130, 251, 21))
        self.txtGroupName.setStyleSheet("background-color: #fff79a")
        self.txtGroupName.setObjectName("txtGroupName")
        self.lblGroupName = QtWidgets.QLabel(CreateLayerGroupDialog)
        self.lblGroupName.setGeometry(QtCore.QRect(10, 130, 141, 21))
        self.lblGroupName.setObjectName("lblGroupName")
        self.lblLayerType = QtWidgets.QLabel(CreateLayerGroupDialog)
        self.lblLayerType.setGeometry(QtCore.QRect(10, 30, 141, 31))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.lblLayerType.setFont(font)
        self.lblLayerType.setObjectName("lblLayerType")
        self.cboLayerType = QtWidgets.QComboBox(CreateLayerGroupDialog)
        self.cboLayerType.setGeometry(QtCore.QRect(160, 30, 221, 31))
        font = QtGui.QFont()
        font.setPointSize(12)
        font.setBold(True)
        font.setWeight(75)
        self.cboLayerType.setFont(font)
        self.cboLayerType.setObjectName("cboLayerType")
        self.cboLayerType.addItem("")
        self.cboLayerType.addItem("")
        self.lblGroupFolder_2 = QtWidgets.QLabel(CreateLayerGroupDialog)
        self.lblGroupFolder_2.setGeometry(QtCore.QRect(340, 160, 181, 21))
        self.lblGroupFolder_2.setObjectName("lblGroupFolder_2")
        self.lblLayerTypeMessage = QtWidgets.QLabel(CreateLayerGroupDialog)
        self.lblLayerTypeMessage.setGeometry(QtCore.QRect(160, 70, 371, 41))
        self.lblLayerTypeMessage.setTextFormat(QtCore.Qt.AutoText)
        self.lblLayerTypeMessage.setObjectName("lblLayerTypeMessage")

        self.retranslateUi(CreateLayerGroupDialog)
        QtCore.QMetaObject.connectSlotsByName(CreateLayerGroupDialog)
        CreateLayerGroupDialog.setTabOrder(self.cboLayerType, self.txtGroupName)
        CreateLayerGroupDialog.setTabOrder(self.txtGroupName, self.txtGeoPackageName)
        CreateLayerGroupDialog.setTabOrder(self.txtGeoPackageName, self.btnCreate)
        CreateLayerGroupDialog.setTabOrder(self.btnCreate, self.btnCancel)

    def retranslateUi(self, CreateLayerGroupDialog):
        _translate = QtCore.QCoreApplication.translate
        CreateLayerGroupDialog.setWindowTitle(_translate("CreateLayerGroupDialog", "Create Layer Group"))
        self.lblGroupFolder.setText(_translate("CreateLayerGroupDialog", "GeoPackage Name"))
        self.txtGeoPackageName.setPlaceholderText(_translate("CreateLayerGroupDialog", "e.g. scenario01"))
        self.btnCreate.setText(_translate("CreateLayerGroupDialog", "Create"))
        self.btnCancel.setText(_translate("CreateLayerGroupDialog", "Cancel"))
        self.txtGroupName.setPlaceholderText(_translate("CreateLayerGroupDialog", "e.g. 1. Major geosites"))
        self.lblGroupName.setText(_translate("CreateLayerGroupDialog", "Group Name"))
        self.lblLayerType.setText(_translate("CreateLayerGroupDialog", "Layer Type"))
        self.cboLayerType.setItemText(0, _translate("CreateLayerGroupDialog", "Scenario Map"))
        self.cboLayerType.setItemText(1, _translate("CreateLayerGroupDialog", "Subject Map"))
        self.lblGroupFolder_2.setText(_translate("CreateLayerGroupDialog", " (single-byte character only)"))
        self.lblLayerTypeMessage.setText(_translate("CreateLayerGroupDialog", "<html><head/><body><p>- Scenario Map =&gt; Create a layer group under the [Scenario] Gourp.</p><p>- Subject Map  =&gt; Create a layer group under the [Subject] Gourp.</p><p><br/></p></body></html>"))

