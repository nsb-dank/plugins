# -*- coding: utf-8 -*-

import os.path
from PyQt5.QtCore import QObject
from PyQt5.QtWidgets import QDialog,QFileDialog
from qgis.core import QgsProject, \
                                QgsSimpleMarkerSymbolLayer, \
                                QgsSvgMarkerSymbolLayer, \
                                QgsSimpleLineSymbolLayer, \
                                QgsSimpleFillSymbolLayer
import qgis.core
from .ui_edit_attribute_dialog import Ui_EditAttributeDialog
from .geolib_util import MapToolUtil

class EditAttributeDialog(QDialog, Ui_EditAttributeDialog):

    def __init__(self, iface):
        QDialog.__init__(self)
        self.iface = iface
        self.ui = Ui_EditAttributeDialog()
        self.ui.setupUi(self)

        #アクティブレイヤーを取得
        self.layer = self.iface.activeLayer()
        self.layerName = self.layer.name()
        # レイヤー種類によってフォームの表示属性を変更
        self.setFormItem(self.layerName)

        #選択地物を取得
        self.features = self.layer.selectedFeatures()
        if self.features is not None:
            self.feature = self.features[0]
            #属性値を取得してフォームにセット
            self.getFeatureValue(self.layer, self.feature)

        # シグナル
        self.ui.cboSymbol.currentIndexChanged.connect(self.cbo_symbol_changed)
        self.ui.btnFileSelect.clicked.connect(self.btn_fileSelect_clicked)
        self.ui.btnPreview.clicked.connect(self.btn_preview_clicked)
        self.ui.btnOK.clicked.connect(self.btn_ok_clicked)
        self.ui.btnCancel.clicked.connect(self.btn_cancel_clicked)

    #シンボルコンボ変更時の処理
    def cbo_symbol_changed(self):
        idx = self.ui.cboSymbol.currentIndex()
        for self.category in self.categories:
            if self.category.value() == self.ui.cboSymbol.itemData(idx):
                #スタイル属属性の初期化
                self._markerType = ""
                self._className = ""
                self._stroke = "True"
                self._color = ""
                self._weight = ""
                self._opacity = ""
                self._fillOpacity = ""
                self._fill = ""
                self._fillColor = ""
                self._dashArray =""
                self._lineCap ="round"
                self._lineJoin = "round"
                self._clickable = "True"
                self._iconUrl =""
                self._iconSize = ""
                self._iconAnchor = ""
                self._iconSize = ""
                self._html = ""
                self._radius =""

                #選択したスタイル属性を取得
                self._className = self.category.label()
                self.ui.txtLegend01.setText(self._className)
                symbol = self.category.symbol().symbolLayer(0)
                if(type(symbol) == QgsSimpleFillSymbolLayer):           #塗りつぶしマーカーの場合
                    self._markerType = ""
                    self._weight = str(symbol.strokeWidth())
                    self._fill = "true"
                    if symbol.strokeStyle()==0:
                        self._stroke = "false"
                    self._opacity = "0.0"
                    self._fillOpacity = "0.5"
                    self._color = symbol.strokeColor().name()
                    self._fillColor = symbol.fillColor().name()

                if(type(symbol) == QgsSimpleLineSymbolLayer):         #ラインマーカーの場合
                    self._markerType = ""
                    self._weight = str(symbol.width())
                    self._stroke = "True"
                    self._opacity = "0.5"
                    self._fillOpacity = ""
                    self._color = symbol.color().name()
                    if symbol.penStyle() != 1:
                        self._dashArray = "5,10"

                if(type(symbol) == QgsSvgMarkerSymbolLayer):          #SVGマーカーの場合
                    self._markerType = "Icon"
                    self._iconSize = "[20,20]"
                    self._iconUrl = os.path.basename(symbol.path())

                if(type(symbol) == QgsSimpleMarkerSymbolLayer):     #シンプルマーカーの場合
                    self._markerType = "Circle"
                    self._weight = "1"
                    self._color = symbol.strokeColor().name()
                    self._fillColor = symbol.color().name()
                    self._radius = str(symbol.size())

    # ファイル選択ボタン押下時の処理
    def btn_fileSelect_clicked(self):
        # ファイル選択ダイアログを開く
        project_path, ext = os.path.splitext(QgsProject.instance().fileName())
        html_path = project_path + "/Scenario" + "/html/"
        html_file_name,_ = QFileDialog.getOpenFileName(self, "Select HTML file(HTML)",
            html_path, "HTML files (*.html;*.htm)")
        if html_file_name:
            self.filename = html_file_name.replace(html_path,"")
            self.ui.txtFilename.setText(self.filename)

    def btn_preview_clicked(self):
        import webbrowser
        project_path, ext = os.path.splitext(QgsProject.instance().fileName())
        html_path = project_path + "/Scenario" + "/html/"
        html_file_name = html_path + self.filename
        webbrowser.open(html_file_name)

    def btn_ok_clicked(self):
        #フォームの入力内容で地物を更新
        mapTool = MapToolUtil()
        layerName = self.layer.name()
        self.layer.startEditing()

        # pntレイヤ
        if layerName.find('pnt')>-1:
            self.feature['remarks'] = self.ui.txtDescription.toPlainText()
            idx = self.ui.cboSymbol.currentIndex()
            self.feature['attribute'] = self.ui.cboSymbol.itemData(idx)
            self.feature['legend01'] = self.ui.txtLegend01.text()

        # strdipレイヤ
        elif layerName.find('strdip')>-1:
            self.feature['remarks'] = self.ui.txtDescription.toPlainText()
            idx = self.ui.cboSymbol.currentIndex()
            self.feature['attribute'] = self.ui.cboSymbol.itemData(idx)
            self.feature['legend01'] = self.ui.txtLegend01.text()
            cbo_strike1 = self.ui.cboStrike1.currentText()
            spn_strike = self.ui.spnStrike.value()
            cbo_strike2 = self.ui.cboStrike2.currentText()
            spn_dip = self.ui.spnDip.value()
            cbo_dip = self.ui.cboDip.currentText()
            strike_val, dip_value = mapTool.setStrDipValue(cbo_strike1, spn_strike, cbo_strike2, spn_dip, cbo_dip)
            self.feature['strike_value'] = strike_val
            self.feature['dip_value'] = dip_value

        # Geo_Lレイヤ
        elif layerName.find('geo_L')>1:
            self.feature['description'] = self.ui.txtDescription.toPlainText()
            idx = self.ui.cboSymbol.currentIndex()
            self.feature['major_code'] = self.ui.cboSymbol.itemData(idx)
            self.feature['legend01'] = self.ui.txtLegend01.text()

        # Geo_Aレイヤ
        elif layerName.find('geo_A')>1:
            self.feature['description'] = self.ui.txtDescription.toPlainText()
            idx = self.ui.cboSymbol.currentIndex()
            self.feature['symbol'] = self.ui.cboSymbol.itemData(idx)
            self.feature['legend01'] = self.ui.txtLegend01.text()
            self.feature['legend02'] = self.ui.txtLegend02.text()
            self.feature['legend03'] = self.ui.txtLegend03.text()
            self.feature['legend04'] = self.ui.txtLegend04.text()
            self.feature['legend05'] = self.ui.txtLegend05.text()
            self.feature['legend06'] = self.ui.txtLegend06.text()
            self.feature['legend07'] = self.ui.txtLegend07.text()

        # Scenarioレイヤ
        else:
            idx = self.ui.cboSymbol.currentIndex()
            self.feature['symbol'] = self.ui.cboSymbol.itemData(idx)
            self.feature['filename'] = self.ui.txtFilename.text()
            self.feature['remarks'] = self.ui.txtDescription.toPlainText()

        #スタイル属性をセット
        self.feature['_markerType'] = self._markerType
        self.feature['_className'] = self._className
        self.feature['_stroke'] = self._stroke
        self.feature['_color'] = self._color
        self.feature['_weight'] = self._weight
        self.feature['_opacity'] = self._opacity
        #self.feature['_fillOpacity'] = self._opacity
        self.feature['_fill'] = self._fill
        self.feature['_fillColor'] = self._fillColor
        self.feature['_dashArray'] = self._dashArray
        self.feature['_lineCap'] = self._lineCap
        self.feature['_lineJoin'] = self._lineJoin
        self.feature['_clickable'] = self._clickable
        self.feature['_iconUrl'] = self._iconUrl
        self.feature['_iconSize'] = self._iconSize
        self.feature['_iconAnchor'] = self._iconAnchor
        self.feature['_iconSize'] = self._iconSize
        self.feature['_html'] = self._html
        self.feature['_radius'] = self._radius

        self.layer.updateFeature(self.feature)
        #Call commit to save the changes
        self.layer.commitChanges()

        self.close()

    def btn_cancel_clicked(self):
        self.close()

    # フォーム表示制御（レイヤー種類によって表示属性を変える）
    def setFormItem(self, layer_name):
        self.ui.lblSymbol.setVisible(True)
        self.ui.cboSymbol.setVisible(True)
        self.ui.lblLegend01.setVisible(False)
        self.ui.txtLegend01.setVisible(False)
        self.ui.frmScenario.setVisible(False)
        self.ui.frmLegend.setVisible(False)
        self.ui.frmStrDip.setVisible(False)

        if layer_name.find('pnt')>-1:
            self.ui.lblLegend01.setVisible(True)
            self.ui.txtLegend01.setVisible(True)

        elif layer_name.find('strdip')>-1:
            self.ui.lblLegend01.setVisible(True)
            self.ui.txtLegend01.setVisible(True)
            self.ui.frmStrDip.setVisible(True)

        elif layer_name.find('geo_L')>1:
            self.ui.lblLegend01.setVisible(True)
            self.ui.txtLegend01.setVisible(True)

        elif layer_name.find('geo_A')>1:
            self.ui.lblLegend01.setVisible(True)
            self.ui.txtLegend01.setVisible(True)
            self.ui.frmLegend.setVisible(True)

        else:
            self.ui.frmScenario.setVisible(True)

    #地物の属性値を取得してフォームにセット（レイヤー種類によって取得属性を変える）
    def getFeatureValue(self,layer,feature):
        layerName = layer.name()
        mapTool = MapToolUtil()

        #シンボルレンダラを取得
        self.renderer = self.layer.renderer()
        self.categories = self.renderer.categories()
        for self.category in self.categories:
            self.ui.cboSymbol.addItem(self.category.label(),self.category.value())

        # pntレイヤ
        if layerName.find('pnt')>-1:
            self.symbol = feature["attribute"]
            self.legend01 = feature['legend01'] if feature['legend01'] != qgis.core.NULL else""
            self.description = feature["remarks"]

            self.ui.txtLegend01.setText(self.legend01)

        # strdipレイヤ
        elif layerName.find('strdip')>-1:
            self.symbol = feature["attribute"]
            self.legend01 = feature['legend01'] if feature['legend01'] != qgis.core.NULL else""
            self.description = feature["remarks"]
            self.strike = feature['strike_value'] if  feature["strike_value"] != qgis.core.NULL else 0
            self.dip = feature['dip_value'] if feature['dip_value'] != qgis.core.NULL else 0
            self.cbo_strike1,self.spn_strike,self.cbo_strike2,self.spn_dip,self.cbo_dip = mapTool.setStrDipText(self.strike, self.dip)

            self.ui.txtLegend01.setText(self.legend01)
            self.ui.cboStrike1.setCurrentIndex(self.ui.cboStrike1.findText(self.cbo_strike1))
            self.ui.spnStrike.setValue(self.spn_strike)
            self.ui.cboStrike2.setCurrentIndex(self.ui.cboStrike2.findText(self.cbo_strike2))
            self.ui.spnDip.setValue(self.spn_dip)
            self.ui.cboDip.setCurrentIndex(self.ui.cboDip.findText(self.cbo_dip))

        # Geo_Lレイヤ
        elif layerName.find('geo_L')>1:
            self.symbol = feature["major_code"]
            self.legend01 = feature['legend01'] if feature['legend01'] != qgis.core.NULL else""
            self.description = feature["description"]

            self.ui.txtLegend01.setText(self.legend01)

        # Geo_Aレイヤ
        elif layerName.find('geo_A')>1:
            self.symbol = feature["symbol"]
            self.legend01 = feature['legend01'] if feature['legend01'] != qgis.core.NULL else""
            self.legend02 = feature['legend02'] if feature['legend02'] != qgis.core.NULL else""
            self.legend03 = feature['legend03'] if feature['legend03'] != qgis.core.NULL else""
            self.legend04 = feature['legend04'] if feature['legend04'] != qgis.core.NULL else""
            self.legend05 = feature['legend05'] if feature['legend05'] != qgis.core.NULL else""
            self.legend06 = feature['legend06'] if feature['legend06'] != qgis.core.NULL else""
            self.legend07 = feature['legend07'] if feature['legend07'] != qgis.core.NULL else""
            self.description = feature["description"]

            self.ui.txtLegend01.setText(self.legend01)
            self.ui.txtLegend02.setText(self.legend02)
            self.ui.txtLegend03.setText(self.legend03)
            self.ui.txtLegend04.setText(self.legend04)
            self.ui.txtLegend05.setText(self.legend05)
            self.ui.txtLegend06.setText(self.legend06)
            self.ui.txtLegend07.setText(self.legend07)

        # Scenarioレイヤ
        else:
            self.symbol = feature["symbol"]
            self.filename =  feature['filename']
            self.description = feature["remarks"]

            if self.filename != qgis.core.NULL:
                self.ui.txtFilename.setText(self.filename)
                project_path, ext = os.path.splitext(QgsProject.instance().fileName())
                html_path = project_path + "/Scenario" + "/html/"
                html_file_name = html_path + self.filename

        # レイヤ共通の属性をセット
        if self.description != qgis.core.NULL:
            self.ui.txtDescription.setPlainText(self.description)

        #シンボル属性を取得してセット
        index = self.ui.cboSymbol.findData(self.symbol)
        self.ui.cboSymbol.setCurrentIndex(index)

        #スタイル属性を取得
        self._markerType = feature['_markerType']
        self._className = feature['_className']
        self._stroke = feature['_stroke']
        self._color = feature['_color']
        self._weight = feature['_weight']
        self._opacity = feature['_opacity']
#     self._fillOpacity = feature['_fillOpacity']
        self._fill = feature['_fill']
        self._fillColor = feature['_fillColor']
        self._dashArray = feature['_dashArray']
        self._lineCap = feature['_lineCap']
        self._lineJoin = feature['_lineJoin']
        self._clickable = feature['_clickable']
        self._iconUrl = feature['_iconUrl']
        self._iconSize = feature['_iconSize']
        self._iconAnchor = feature['_iconAnchor']
        self._iconSize = feature['_iconSize']
        self._html = feature['_html']
        self._radius = feature['_radius']


